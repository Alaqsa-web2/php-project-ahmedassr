
<?php
include("connection.php");

if(isset($_POST['AddComment'])){
    $user_id = $_POST['user_id'];
    $commentText = $_POST['CommentText'];
    $post_id = $_POST['post_id'];
    date_default_timezone_set('Asia/Gaza');
    $date = date("d/M/Y h:iA");
    mySQLi_query($conn,"INSERT INTO comments (text,Created_at,post_id,user_id)
	VALUES ('$commentText','$date','$post_id','$user_id')");
			echo "<script>window.location='project01-1.php'</script>";
}


?>