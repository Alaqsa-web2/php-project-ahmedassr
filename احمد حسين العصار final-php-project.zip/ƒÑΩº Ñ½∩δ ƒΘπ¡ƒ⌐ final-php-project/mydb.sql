-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 02, 2022 at 01:19 PM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.1.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mydb`
--

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `Comment_id` int(12) NOT NULL,
  `text` varchar(200) NOT NULL,
  `Created_at` varchar(50) NOT NULL,
  `post_id` int(12) NOT NULL,
  `user_id` int(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`Comment_id`, `text`, `Created_at`, `post_id`, `user_id`) VALUES
(132867, 'it\'s so nice ', '2022-05-26', 124, 12),
(132868, 'no this is a big problem', '2022-05-13', 123, 13),
(132869, 'i well vist it', '2022-05-25', 122, 4),
(132870, 'im ahmed', '2022-05-24', 125, 1),
(132871, 'it\'s grate seeing you man', '2022-05-11', 122, 27),
(132872, 'comment 2', '2022-05-27', 123, 28),
(132873, 'amal', '2022-05-26', 123, 16),
(132874, 'test1', '02/Jul/2022 12:41AM', 122, 12),
(132875, 'test22', '02/Jul/2022 12:41AM', 123, 12),
(132876, 'so good', '02/Jul/2022 12:41AM', 124, 12),
(132877, 'so good', '02/Jul/2022 12:41AM', 124, 12),
(132878, 'ww', '02/Jul/2022 01:51AM', 135, 4),
(132879, 'yes go', '02/Jul/2022 01:51PM', 137, 13),
(132880, 'ahmed', '02/Jul/2022 01:51PM', 137, 13);

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `post_id` int(11) NOT NULL,
  `text` varchar(200) NOT NULL,
  `picture` varchar(50) NOT NULL,
  `Create_at` varchar(50) NOT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`post_id`, `text`, `picture`, `Create_at`, `user_id`) VALUES
(122, 'paris', 'AAE8Vai.jfif', '2010-01-10', 12),
(123, 'disan land', 'wallpaperbetter.jpg', '2010-01-10', 12),
(124, 'italia', 'BB1bnyDl.jfif', '2010-01-10', 13),
(125, 'karipy', 'AAWaDdw.jfif', '2010-01-10', 13),
(127, 'my first post                    ', 'man.jpg', '2010-01-10', 4),
(128, '2 post                    ', 'AAOnVef.jfif', '2010-01-10', 4),
(129, '                        Type your post here...\r\n                    ', 'AAKlU4R.jfif', '2010-01-10', 4),
(130, '                        Type your post', 'BB1bnebF.jfif', '2010-01-10', 12),
(131, '                 post one\r\n                    ', 'Untitled-2.jpg', '2010-01-10', 12),
(132, 'post with timestamp', 'download.png', '0000-00-00', 12),
(133, '                        Type your post here...\r\n                    ', 'Untitled-9.jpg', '0000-00-00', 12),
(134, '                        Type your post here...\r\n                    ', 'download.png', '29/Jun/2022 03:45PM', 12),
(135, 'welecam  in my profile', 'count.png', '02/Jul/2022 01:51AM', 4),
(136, 'post 1                    ', 'download.png', '02/Jul/2022 01:51PM', 13),
(137, 'post 22', 'game.jfif', '02/Jul/2022 01:51PM', 13);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `picture` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`, `picture`) VALUES
(1, 'dania', 'ahmed@360gmail.com', '123', 'Introduction.jpg'),
(4, 'amal', 'ahmal36@gmail.com', '123', 'girlface.jpg'),
(12, 'aaa', 'ahmed360@gmail.com', 'aaa', 'Untitled-9.jpg'),
(13, 'aa', 'ss33@gmail.com', '12', 'error.jpg'),
(16, 'nour', 'nour360@gmail.com', '2150090', 'girlface.jpg'),
(18, 'nour11', 'nour360@gmail.com', '1111', ''),
(23, 'nour11sss', 'nour360@gmail.com', '123', ''),
(24, 'nour11sss333', 'nour360@gmail.com', '9999', ''),
(26, 'ahmed360', 'as598102@icloud.com', '44', ''),
(27, 'assr', 'nour360@gmail.com', '11', ''),
(28, 'ala', 'ahmedassr360@gmail.com', '11', ''),
(30, 'ahmed000', 'as598102@icloud.com', '123', ''),
(31, 'ahmed215', 'nour360@gmail.com', '111', ''),
(32, 'ahmed21511', 'nour360@gmail.com', '11', ''),
(33, 'amal326', 'ahmedn77@gmail.com', '360', ''),
(34, 'ahmedzxzx', 'as598102@icloud.com', '87879', ''),
(35, 'zidddd', 'as598102@icloud.com', '123', ''),
(36, 'ziddddwww', 'as598102www@icloud.com', '123', ''),
(37, 'omar', 'omar33@gmail.com', '123', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`Comment_id`),
  ADD KEY `TEST2` (`post_id`),
  ADD KEY `TEST3` (`user_id`);

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`post_id`),
  ADD KEY `TEST` (`user_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username_3` (`username`),
  ADD UNIQUE KEY `username_5` (`username`),
  ADD KEY `username` (`username`),
  ADD KEY `username_2` (`username`),
  ADD KEY `username_4` (`username`),
  ADD KEY `username_6` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `Comment_id` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=132881;

--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `post_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=138;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `comments`
--
ALTER TABLE `comments`
  ADD CONSTRAINT `TEST2` FOREIGN KEY (`post_id`) REFERENCES `posts` (`post_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `TEST3` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `posts`
--
ALTER TABLE `posts`
  ADD CONSTRAINT `TEST` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
