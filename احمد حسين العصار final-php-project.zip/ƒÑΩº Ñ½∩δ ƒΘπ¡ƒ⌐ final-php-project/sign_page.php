<?php

include("connection.php");


if ($_SERVER['REQUEST_METHOD'] == "POST") {

  $res = true;
  $username_sign_up = $_POST["user_sign_up"];
  $password_sign_up = $_POST["password_sign_up"];
  $confairm_password = $_POST["confairm_password"];
  $email = $_POST["email"];
  if (!empty($username_sign_up) && !empty($password_sign_up) && !empty($email)) {
    $query = "select * from users;";
    $result = mysqli_query($conn, $query);
    if ($result->num_rows > 0) {
      while ($row = $result->fetch_assoc()) {

        if ($row['username'] == $username_sign_up) {
          $res = false;
        }
      }
    }

    if ($res) {
      $sql = mysqli_prepare($conn, "INSERT INTO users (username,email,password) VALUES(?,?,?)");
      $sql->bind_param("ssi", $username_sign_up, $email, $password_sign_up);


      if ($sql->execute()) {
        echo "success";
      }
    } else {
      $error = 'some thing error or please enter another user name';
    }


    header("location:sign_page.php");
    die;
  } else {
  }
} else {
  $error = 'please enter some valid input';
}


?>

<?php
 
if ($_SERVER['REQUEST_METHOD'] == "POST") {
  $username_sign_in = $_POST['user'];
  $password_sign_in = $_POST['password'];
  if (!empty($username_sign_in) && !empty($password_sign_in)) {
    if (isset($_POST['sign_in_btn'])) {
      $sql = "select * from users where username=? and password=?";

      $sql = mysqli_prepare($conn, $sql);
      mysqli_stmt_bind_param($sql, 'ss', $username_sign_in, $password_sign_in);
      mysqli_stmt_execute($sql);

      $res = mysqli_stmt_get_result($sql);
      if ($res->num_rows > 0) {
        session_start();
        while($row = $res->fetch_assoc()){
          $_SESSION['id'] = $row['id'];
          $_SESSION['username'] = $row['username'];
          $_SESSION['email'] = $row['email'];
          $_SESSION['picture'] = $row['picture'];
          
        }
        header("location:project01-1.php");
      } else echo "faild";

     
    }
  }
}



?>

 





<!DOCTYPE html>
<html lang="en">

<head>
  <link rel="stylesheet" href="LoginPage.css" type="text/css" />
  <title>Document</title>
  <?php
  ?>
</head>

<body>
  <form method="post">
    <div class="login-wrap">

      <div  class="login-html">

        <input id="tab-1" type="radio" name="tab" class="sign-in" checked><label for="tab-1" class="tab">Sign In</label>

        <input id="tab-2" type="radio" name="tab" class="sign-up"><label for="tab-2" class="tab">Sign Up</label>

        <div class="login-form">

          <div id="sign-in-htm" class="sign-in-htm">

            <div class="group">

              <label for="user" class="label">Username</label>

              <input id="user" name="user" type="text" class="input">
            </div>

            <div class="group">

              <label for="pass" class="label">Password</label>

              <input id="pass" type="password" name="password" class="input" data-type="password">

            </div>

            <div class="group">

              <input id="check" type="checkbox" class="check" checked>

              <label for="check"><span class="icon"></span> Keep me Signed in</label>

            </div>

            <div class="group">

              <input id="sign_in_btn" type="submit" name="sign_in_btn" class="button" value="Sign In">

            </div>

            <div class="hr"></div>

            <div class="foot-lnk">

              <a href="#forgot">Forgot Password?</a>

            </div>

          </div>

          <div id="sign-up-htm" class="sign-up-htm">

            <div class="group">

              <label for="user" class="label">Username</label>

              <input id="user" name="user_sign_up" type="text" class="input">

            </div>

            <div class="group">

              <label for="pass" class="label">Password</label>

              <input id="pass" type="password" name="password_sign_up" class="input" data-type="password">

            </div>

            <div class="group">

              <label for="pass" class="label">Repeat Password</label>

              <input id="pass" type="password" name="confairm_password" class="input" data-type="password">

            </div>

            <div class="group">

              <label for="pass" class="label">Email Address</label>

              <input id="pass" type="text" name="email" class="input">

            </div>

            <div class="group">

              <input type="submit" name="sign_up_btn" class="button" value="Sign Up">

            </div>

            <div class="hr"></div>

            <div class="foot-lnk">
              <label for="tab-1"><?php if (isset($error)) echo $error; ?></a> <br>
                <label for="tab-1">Already Member?</a>

            </div>

          </div>

        </div>

      </div>

    </div>


  </form>
</body>

</html>