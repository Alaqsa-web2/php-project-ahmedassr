

<?php
include("connection.php");
session_start();
if(isset($_POST['edit_button'])){
$username = $_POST['edit_username'];
$password = $_POST['edit_password'];
$email = $_POST['edit_email'];
$id = $_SESSION['id'];

    mySQLi_query($conn," UPDATE users
    SET username = '$username',
    password = '$password',
    email = '$email'
    WHERE id='$id';");

    
echo "<script>window.location='profile.php'</script>";

}

?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit My Profile</title>
    <link href="EditProfile.css" rel="stylesheet">

</head>

<body>
    <div class="container">
        <h1 class="text-primary">Edit Profile</h1>
        <hr>
        <div class="row">
            <!-- left column -->
            <div class="col-md-3">
                <div class="text-center">
<?php
$photo = $_SESSION['photo'];
  echo '<img class="img-responsive center-block" style=" border-radius: 150px; width: 250px; height: 240px;" src="ImageProfile\\' . $photo . ' " alt=" Select Your Profile Image Please"> <br>';
?>
                </div>
            </div>

            <!-- edit form column -->

            <h3>Personal info</h3>

            <form class="form-horizontal" role="form" action="EditProfile.php" method="POST">
                <div class="form-group">
                    <label class="col-lg-3 control-label">User Name :</label>
                    <div class="col-lg-8">
                        <input class="form-control" name="edit_username" type="text">
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-lg-3 control-label">Password :</label>
                    <div class="col-lg-8">
                        <input class="form-control" name="edit_password" type="password">
                    </div>
                </div>

                <div class="form-group">
                    <label class="col-lg-3 control-label">Email:</label>
                    <div class="col-lg-8">
                        <input class="form-control" name="edit_email" type="text">
                    </div>
                </div>

                <div class="form-group">
                    <div class="col-lg-8" style="margin-top: 20px;">
                        <input style="border-radius: 15px; height: 50px; width: 90px; background-color: #008dcb;" class="form-control" name="edit_button" type="submit" value="Edit">

                    </div>
                </div>

        </div>
    </div>
    </form>
    </div>
    </div>
    </div>
    <hr>
</body>

</html>