<?php

include("connection.php");
session_start();
$id = $_SESSION['id'];
$name = $_SESSION['username'];
$email = $_SESSION['email'];
$msg = '';

if (isset($_POST['PostButton'])) {
    date_default_timezone_set('Asia/Gaza');
    $date = date("d/M/Y h:iA");
    $target = "image/" . basename($_FILES['file']['name']);
    $image = $_FILES['file']['name'];
    $PostText = $_POST['PostText'];
    $sql = "INSERT INTO posts (text,picture,Create_at,user_id) VALUES ('$PostText','$image','$date','$id');";
    mysqli_query($conn, $sql);

    if (move_uploaded_file($_FILES['file']['tmp_name'], $target)) {
        $msg = 'image uploade successfully';
    } else {
        $msg = 'image uploade falire';
    }
    header("location:project01-1.php");
}

$query_user_photo = "SELECT * FROM users WHERE $id=id";
$res_user_photo = mysqli_query($conn, $query_user_photo);
$row_user_photo = mysqli_fetch_array($res_user_photo);





?>






<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!--Bootstrap 5 css-->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <!--font-awesome-->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <!--style-->
    <link rel="stylesheet" href="style.css">
    <title>Social Media</title>
</head>

<body>

    <!--start nav bar-->
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="container-fluid">
            <a class="navbar-brand brand">Social Media</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarText" aria-controls="navbarText" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarText" style="flex-grow: 0;">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">

                    <p class="navbar-brand text"> <?php echo $name; ?> </p>
                    <p class="navbar-brand text">EMAIL : <?php echo $email; ?> </p>

                    <li class="nav-item">
                        <a class="nav-link " aria-current="page" href="sign_page.php">LOGIN</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link asignUp" href="sign_page.php">SIGNUP</a>
                    </li>
                </ul>
                <!--if login-->
                <!-- <div class="flexPostForm">
            <div class="imgPostForm imgHead" >
                <img src="img/man.jpg" alt="">
            </div>
            <div class="namePostCard">
                <p class="name">Omar Khaled</p>
            </div>   
        </div>  -->
            </div>
        </div>
    </nav>
    <!--end nav bar-->

    <!--start content-->
    <div class="container">
        <div class="postForm">
            <div class="flexPostForm">
                <a href="profile.php">
                    <div class="imgPostForm">
                        <?php echo ' <img  alt="no photo" src="ImageProfile\\' . $row_user_photo['picture'] . '" >'; ?>
                        <p style="font-size: 12px; color: black; padding-left: 5px;"> <?php echo   $name; ?> </p>
                    </div>
                </a>
                <input data-bs-toggle="modal" data-bs-target="#exampleModal" class="form-control" type="text" placeholder="Type Your Post Here" aria-label=".form-control-lg example">
                <!-- Modal -->
                <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <form action="project01-1.php" method="POST" enctype="multipart/form-data">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="exampleModalLabel">Create Post</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                </div>
                                <div class="modal-body">
                                    <textarea class="form-control txtPostModal" name="PostText" id="exampleFormControlTextarea1" rows="3">
                        Type your post here...
                    </textarea>
                                    <input class="form-control" name="file" type="file" id="formFile">
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                    <button type="submit" class="btn btn-primary" name="PostButton">Post</button>
                                </div>
                            </div>
                        </div>
                </div>
                </form>
            </div>
        </div>


        <?php
        $post_id_comments = null;
        if (1 == 1) {
            $query_posts = "SELECT * FROM posts";
            $query_users = "SELECT * FROM users INNER JOIN posts ON users.id = posts.user_id";
            $r_posts = mysqli_query($conn, $query_posts);
            $res_users = mysqli_query($conn, $query_users);
        }

        while (($row = mysqli_fetch_array($r_posts)) &&  ($row_users = mysqli_fetch_array($res_users))) {
            echo '  <div class="postCard">
                        <div class="postForm">
                            <div class="flexPostForm">
                                <div class="imgPostForm">';
            echo ' <img  alt="no photo" src="ImageProfile\\' . $row_users['picture'] . '" >';

            echo ' </div>';

            echo '<div class="namePostCard">';
            echo   '<p class="name">' . $row_users['username'] . '</p>';
            echo ' <div class="divTime">
                                        <i class="fa-solid fa-clock"></i>';
                                       echo '<p>'.$row['Create_at'].'</p>';
                                    echo'</div>
                                </div>
                            </div>';




            echo '<div class="imgPost">';
            echo "<p>" . $row['text'] . "</p>";
            echo ' <img class="img-fluid rounded" alt="no photo" src="image\\' . $row['picture'] . ' " />';
            echo   "</div>";

            echo '
                    
                <div>
                    <div class="flexPostForm">
                        <div class="imgPostForm">';
            echo ' <img  alt="no photo" src="ImageProfile\\' . $row_user_photo['picture'] . '" >';
            echo   '<p style="font-size: 12px; color: black; padding-left: 5px;">' .   "$name" . '</p>';
            echo '</div>                    
                    <form  action="project01-1.php" method="POST">
                        <input  type="text" name="CommentText" placeholder="Type your comment" aria-label=".form-control-lg example">
                        <input name="AddComment" type="submit" value="Add Comment">
                    </form>
                        </div>
                        </div>';
            $query_show_comments = "SELECT * FROM comments WHERE post_id = $row[post_id]";
            $result_show_comments = mysqli_query($conn, $query_show_comments);
            if ($result_show_comments) {
                while ($row_show_comments = mysqli_fetch_array($result_show_comments)) {
                    $query_show_comments2 = "SELECT * FROM users WHERE id ='$row_show_comments[user_id]'";
                    $result_show_comments2 = mysqli_query($conn, $query_show_comments2);
                    if ($result_show_comments2) {
                        while ($row_show_comments2 = mysqli_fetch_array($result_show_comments2)) {



                            echo '  
                                <hr class="hr">
                                <div class="comment">
                                    <div class="flexPostForm">
                                        <div class="imgPostForm">';
                            echo ' <img  alt="no photo" src="ImageProfile\\' . $row_show_comments2['picture'] . '" >';
                            echo '   </div>
                                        <div class="boxComment">';
                            echo '<p class="nameBoxComment">' . $row_show_comments2['username'] . '</p>';
                            echo  '<p class="contentBoxComment">' . $row_show_comments['text'] . '</p>';
                            echo ' <div class="divTime">
                                                <i class="fa-solid fa-clock"></i>';
                                                echo'<p>'.$row_show_comments['Created_at'].'</p>';
                                           echo '</div>
                                        </div>
                                    </div>
                                </div>';
                        }
                    }
                }
            }

            if ((isset($_POST['AddComment']))) {
            }
        }

        while ((isset($_POST['AddComment']))) {
            date_default_timezone_set('Asia/Gaza');
            $date = date("d/M/Y h:iA");

            $query_comments = "SELECT * FROM posts WHERE post_id ='$post_id_comments';";


            $result = mysqli_query($conn, $query_comments);
            if ($row_comments = mysqli_fetch_array($result)) {
                $CommentText = $_POST['CommentText'];
                $PostId = $row_comments['post_id'];
                $stm = "INSERT INTO comment (text, Created_at ,post_id,user_id) VALUES ('$CommentText','$date','$PostId','$id');";
                mysqli_query($conn, $stm);
                $_POST['AddComment'] = null;
            }
        }




        ?>






        <!--end content-->


        <!--Bootstrap 5 js-->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>

</body>

</html>