<?php


$server = "localhost";
$username = "root";
$password = "";
$db = "mydb";
$conn = mysqli_connect($server, $username, $password, $db);
if (mysqli_errno($conn)) {
    die(mysqli_errno($conn));
}

 
?>