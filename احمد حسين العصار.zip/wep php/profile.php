<?php
include("connection.php");
session_start();
$id = $_SESSION['id'];

if (isset($_POST['BtnAddImage'])) {
    $target = "ImageProfile/" . basename($_FILES['file']['name']);
    $image = $_FILES['file']['name'];
    $sql = "UPDATE users
    SET picture = '$image'
    WHERE id='$id';";
    $res =  mysqli_query($conn, $sql);
    if ($res) {
        echo true;
    }
    if (move_uploaded_file($_FILES['file']['tmp_name'], $target)) {
        $msg = 'image uploade successfully';
    } else {
        $msg = 'image uploade falire';
    }
    header("location:profile.php");
}



?>

























<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="style.css" rel="stylesheet">

</head>

<body style="margin-left: 20px; margin-right: 20px; background-color: rgb(20, 49, 89);">
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css" rel="stylesheet">
    <div class="container">
        
    <div class="row">

            <div class="col-sm-3">
                <form action="profile.php" method="POST" enctype="multipart/form-data">
                    <?php
                    $query_uesr = "SELECT * FROM users WHERE id= '$id';";
                    $query_post = "SELECT * FROM posts WHERE  user_id= '$id';";
                    $result = mysqli_query($conn, $query_uesr);
                    $result_post = mysqli_query($conn, $query_post);
                    if ($result && $result_post) {
                        while (($row = mysqli_fetch_array($result)) && $row_post = mysqli_fetch_array($result_post)) {

                            echo '                  <div style="margin-left: 590px;" class="user-profile__avatar shadow-effect text-center">';

                            echo '<img class="img-responsive center-block" style=" border-radius: 150px; width: 250px; height: 240px;" src="ImageProfile\\' . $row['picture'] . ' " alt=" Select Your Profile Image Please"> <br>';

                            echo '
Add your Image <br>
<input class="form-control" name="file" type="file">
<br>
<br>
<button style="border-radius: 15px; height: 50px; width: 90px; background-color: #008dcb;" name="BtnAddImage">
    <b>Save Image</b> </button>

</div>

</form>';
                            echo '<div style="margin-left: 580px; margin-Top: 20px; background-color: rgb(223, 106, 17) ; max-width: 300px; height: 60px;border-radius: 15px; padding: 15px; >';
                            echo '<p class="text-muted">' . 'User Name :' . $row['username'] . '</p>';
                            echo '<p class="text-muted">' . 'Email :' . $row['email'] . '</p>';
                            echo '</div>';

                            echo '
<div style="margin-left: 630px; margin-Top: 20px;" class="panel panel-default">
<div class="panel-heading">
User Menu
</div>
<div class="panel-body">
<ul>
    <li><a href="#"><i class="fa fa-user"></i> My Profile</a></li>
    <li><a href="#"><i class="fa fa-edit"></i> Edit Profile</a></li>
    <li><a href="sign_page.php"><i class="fa fa-sign-out"></i> Sign Out</a></li>
</ul>
</div>
</div>

</div>
<div style="margin-left: 630px; margin-Top: 20px;" class="col-sm-6">

<!-- Profile info -->
<ul class="user-profile__info">
    <li>
        <i class="fa fa-calendar-o"></i> Member for 180 days
    </li>
    <li>
        <i class="fa fa-clock-o"></i> Last seen 2 hours ago
    </li>
    <li>
        <i class="fa fa-eye"></i> 50 profile views
    </li>
</ul>
</div>

</div>';

                            // post's info
                            while ($row_post = mysqli_fetch_array($result_post)) {


                                echo '  <div class="postCard">
<div class="postForm">
    <div class="flexPostForm">
        <div class="imgPostForm">';
                                echo '<img  src="ImageProfile\\' . $row['picture'] . ' " alt=" Select Your Profile Image Please"> <br>';

                                echo ' </div>';

                                echo '<div class="namePostCard">';
                                echo   '<p class="name">' . $row['username'] . '</p>';
                                echo ' <div class="divTime">
                <i class="fa-solid fa-clock"></i>
                <p>4h</p>
            </div>
        </div>
    </div>';


                                echo '<div class="imgPost">';
                                echo "<p>" . $row_post['text'] . "</p>";
                                echo ' <img class="img-fluid rounded" alt="no photo" src="image\\' . $row_post['picture'] . ' " />';
                                echo   "</div>";

                                echo '
    
<div>
    <div class="flexPostForm">
        <div class="imgPostForm">';
                                echo '<img  src="ImageProfile\\' . $row['picture'] . ' " alt=" Select Your Profile Image Please"> <br>';
                                // echo ' <img  alt="no photo" src="ImageProfile\\'.$row_users['picture'].' " />';
                                echo '</div>                    
    <form  action="project01-1.php" method="GET">
        <input class="form-control"  type="text" name="CommentText" placeholder="Type your comment" aria-label=".form-control-lg example">
    </form>
        </div>';
                                $query_show_comments = "SELECT * FROM comments WHERE post_id = $row_post[post_id]";
                                $result_show_comments = mysqli_query($conn, $query_show_comments);
                                if ($result_show_comments) {
                                    while ($row_show_comments = mysqli_fetch_array($result_show_comments)) {
                                        $query_show_comments2 = "SELECT * FROM users WHERE id ='$row_show_comments[user_id]'";
                                        $result_show_comments2 = mysqli_query($conn, $query_show_comments2);
                                        if ($result_show_comments2) {
                                            while ($row_show_comments2 = mysqli_fetch_array($result_show_comments2)) {



                                                echo '  
                            <hr class="hr">
                            <div class="comment">
                                <div class="flexPostForm">
                                    <div class="imgPostForm">';
                                                echo ' <img  alt="no photo" src="ImageProfile\\' . $row_show_comments2['picture'] . '" >';
                                                echo '   </div>
                                    <div class="boxComment">';
                                                echo '<p class="nameBoxComment">' . $row_show_comments2['username'] . '</p>';
                                                echo  '<p class="contentBoxComment">' . $row_show_comments['text'] . '</p>';
                                                echo ' <div class="divTime">
                                            <i class="fa-solid fa-clock"></i>
                                            <p>4h</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            ';
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    echo '</div>';

                    ?>


<div style="margin-left: 50px; margin-top: 100px;">
<label style="background-color: saddlebrown; margin-left: 70px;">Edit your data</label>

        <div class="group" style="margin-top: 20px;">

            <label for="user" class="label">Username</label>

            <input style="margin-left:44px;" id="user" name="username_edit" type="text" class="input">

        </div>

        <div class="group" style="margin-top: 20px;">

            <label for="pass" class="label">Password</label>

            <input style="margin-left:46px;" id="pass" type="password" name="password_edit" class="input" data-type="password">

        </div>


        <div class="group" style="margin-top: 20px;">

            <label for="pass" class="label">Email Address</label>

            <input style="margin-left:15px;" id="pass" type="text" name="email_edit" class="input">

        </div>

        <div class="group" style="margin-top: 20px;">

            <input type="submit" name="btn_edit" class="button" value="Sign Up">

        </div>

</body>


</html>